# Fikra Payment Integration Guide

## 1. Chapa (Ethiopia) – Recommended for local users

1. Go to https://chapa.co and create an account
2. Get your **Secret Key** and **Public Key** from the Dashboard
3. Open `lib/core/services/payment/payment_service.dart`
4. Replace:
   ```dart
   static const String chapaSecretKey = 'CHASECK_TEST-xxxxxxxx';
   static const String chapaPublicKey = 'CHAPUBK_TEST-xxxxxxxx';
   ```
5. For production change the base URL if needed and use live keys.

### How it works
- App calls Chapa `/transaction/initialize`
- User is redirected to Chapa checkout page
- After payment, call `verifyChapaPayment(txRef)` to confirm

## 2. Stripe (International)

1. Create account at https://stripe.com
2. Get **Publishable key** (safe for client) and **Secret key** (backend only)
3. You **must** create a PaymentIntent on your backend
4. Example backend endpoint needed:
   ```
   POST /api/payment/stripe/create-intent
   Body: { amount, currency, email, metadata }
   Returns: { clientSecret }
   ```
5. Then use `flutter_stripe` package on the client with the clientSecret.

## 3. Telebirr
Telebirr is supported through Chapa (select payment_options: telebirr) or via official Telebirr merchant API.

## Security Notes
- Never put Stripe Secret Key or Chapa Secret Key in production mobile code if possible.
- Best practice: create a small backend (Node / Supabase Edge Function) that holds the secret keys and creates the payment sessions.
- Always verify payments on the server side before unlocking the account.

## Test Mode
Both Chapa and Stripe provide test keys. Use them during development.
