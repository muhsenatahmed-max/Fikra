import 'package:flutter/foundation.dart';
import '../../core/services/supabase_service.dart';

class ProfileRepository {
  final _client = SupabaseService.client;

  /// Get current user profile
  Future<Map<String, dynamic>?> getMyProfile() async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) return null;

    final data = await _client
        .from('profiles')
        .select('*, user_photos(*), user_interests(*), user_preferences(*)')
        .eq('id', userId)
        .maybeSingle();
    return data;
  }

  /// Update profile
  Future<void> updateProfile({
    String? fullName,
    DateTime? birthDate,
    String? gender,
    String? bio,
    String? preferredLanguage,
  }) async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) throw Exception('Not logged in');

    final updates = <String, dynamic>{
      'updated_at': DateTime.now().toIso8601String(),
    };
    if (fullName != null) updates['full_name'] = fullName;
    if (birthDate != null) updates['birth_date'] = birthDate.toIso8601String().split('T').first;
    if (gender != null) updates['gender'] = gender;
    if (bio != null) updates['bio'] = bio;
    if (preferredLanguage != null) updates['preferred_language'] = preferredLanguage;

    await _client.from('profiles').update(updates).eq('id', userId);
  }

  /// Save interests
  Future<void> saveInterests(List<String> interests) async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) throw Exception('Not logged in');

    // Delete old
    await _client.from('user_interests').delete().eq('user_id', userId);

    // Insert new
    if (interests.isNotEmpty) {
      await _client.from('user_interests').insert(
        interests.map((i) => {'user_id': userId, 'interest': i}).toList(),
      );
    }
  }

  /// Get discover profiles (simple version)
  Future<List<Map<String, dynamic>>> getDiscoverProfiles({
    int limit = 20,
  }) async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) return [];

    try {
      // Exclude already liked / blocked users (simplified)
      final data = await _client
          .from('profiles')
          .select('*, user_photos(*), user_interests(*)')
          .neq('id', userId)
          .order('last_active', ascending: false)
          .limit(limit);

      return List<Map<String, dynamic>>.from(data);
    } catch (e) {
      debugPrint('getDiscoverProfiles error: $e');
      return [];
    }
  }

  /// Like a user
  Future<bool> likeUser(String toUserId) async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) return false;

    try {
      await _client.from('likes').insert({
        'from_user_id': userId,
        'to_user_id': toUserId,
      });
      // The database trigger will create a match if mutual
      return true;
    } catch (e) {
      debugPrint('likeUser error: $e');
      return false;
    }
  }

  /// Get my matches
  Future<List<Map<String, dynamic>>> getMatches() async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) return [];

    final data = await _client
        .from('matches')
        .select('''
          id, created_at,
          user1:profiles!matches_user1_id_fkey(id, full_name, user_photos(*)),
          user2:profiles!matches_user2_id_fkey(id, full_name, user_photos(*))
        ''')
        .or('user1_id.eq.$userId,user2_id.eq.$userId')
        .order('created_at', ascending: false);

    return List<Map<String, dynamic>>.from(data);
  }

  /// Record successful payment
  Future<void> recordPayment({
    required double amount,
    required String currency,
    required String paymentType,
    required String provider,
    required String transactionId,
  }) async {
    final userId = SupabaseService.currentUserId;
    if (userId == null) throw Exception('Not logged in');

    await _client.from('payments').insert({
      'user_id': userId,
      'amount': amount,
      'currency': currency,
      'payment_type': paymentType,
      'payment_provider': provider,
      'transaction_id': transactionId,
      'status': 'success',
    });
  }
}
