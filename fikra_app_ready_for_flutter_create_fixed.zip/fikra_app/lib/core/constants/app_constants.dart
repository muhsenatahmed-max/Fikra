class AppConstants {
  static const String appName = 'Fikra';
  static const String tagline = 'ፍቅር ይጀምራል';
  static const String taglineEn = 'Where hearts connect';

  // ============================================================
  //  SUPABASE – Replace with your real project values
  //  Create project at https://supabase.com
  // ============================================================
  static const String supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';
  static const String supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';

  // Registration fee (localized later)
  static const double registrationFeeETB = 150;
  static const double registrationFeeUSD = 4.99;
  static const double registrationFeeEUR = 4.99;

  // Premium
  static const double premiumMonthlyUSD = 2.99;
  static const double premium3MonthsUSD = 6.99;
  static const double premiumYearlyUSD = 19.99;

  // Age range
  static const int minAge = 18;
  static const int maxAge = 70;

  // Limits
  static const int freeDailyLikes = 20;
  static const int premiumDailyLikes = 9999;
}
