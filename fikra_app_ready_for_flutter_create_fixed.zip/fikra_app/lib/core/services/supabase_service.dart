import 'package:supabase_flutter/supabase_flutter.dart';
import '../constants/app_constants.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;
  static GoTrueClient get auth => client.auth;
  static SupabaseStorageClient get storage => client.storage;
  static RealtimeClient get realtime => client.realtime;

  /// Call this once in main() before runApp
  static Future<void> initialize() async {
    // Keep the UI runnable until real Supabase credentials are configured.
    if (AppConstants.supabaseUrl.contains('YOUR_PROJECT_ID') ||
        AppConstants.supabaseAnonKey == 'YOUR_SUPABASE_ANON_KEY') {
      return;
    }
    await Supabase.initialize(
      url: AppConstants.supabaseUrl,
      anonKey: AppConstants.supabaseAnonKey,
      authOptions: const FlutterAuthClientOptions(
        authFlowType: AuthFlowType.pkce,
      ),
    );
  }

  static User? get currentUser => auth.currentUser;
  static String? get currentUserId => currentUser?.id;
  static bool get isLoggedIn => currentUser != null;

  static Stream<AuthState> get authStateChanges => auth.onAuthStateChange;
}
