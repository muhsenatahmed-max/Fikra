import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:uuid/uuid.dart';
import '../../constants/app_constants.dart';

enum PaymentProvider { chapa, telebirr, stripe }

enum PaymentStatus { pending, success, failed, cancelled }

class PaymentResult {
  final PaymentStatus status;
  final String? transactionId;
  final String? checkoutUrl;
  final String? message;
  final Map<String, dynamic>? raw;

  PaymentResult({
    required this.status,
    this.transactionId,
    this.checkoutUrl,
    this.message,
    this.raw,
  });
}

class PaymentService {
  // ============================================================
  //  IMPORTANT: Replace these with your real keys
  // ============================================================
  static const String chapaSecretKey = 'CHASECK_TEST-xxxxxxxxxxxxxxxxxxxx'; // from Chapa dashboard
  static const String chapaPublicKey = 'CHAPUBK_TEST-xxxxxxxxxxxxxxxxxxxx';
  static const String stripePublishableKey = 'pk_test_xxxxxxxxxxxxxxxxxxxx';
  // Stripe secret key must stay on your backend only!

  static const String chapaBaseUrl = 'https://api.chapa.co/v1';

  /// Initiate registration payment
  Future<PaymentResult> initiateRegistrationPayment({
    required PaymentProvider provider,
    required String userEmail,
    required String userPhone,
    required String firstName,
    required String lastName,
    String currency = 'ETB',
    double? amount,
  }) async {
    final finalAmount = amount ?? AppConstants.registrationFeeETB;
    final txRef = 'fikra_reg_${const Uuid().v4().substring(0, 12)}';

    switch (provider) {
      case PaymentProvider.chapa:
        return _initiateChapa(
          amount: finalAmount,
          currency: currency,
          email: userEmail,
          phone: userPhone,
          firstName: firstName,
          lastName: lastName,
          txRef: txRef,
        );
      case PaymentProvider.telebirr:
        // Telebirr is usually handled through Chapa or a dedicated Telebirr API
        return _initiateChapa(
          amount: finalAmount,
          currency: currency,
          email: userEmail,
          phone: userPhone,
          firstName: firstName,
          lastName: lastName,
          txRef: txRef,
          preferredMethod: 'telebirr',
        );
      case PaymentProvider.stripe:
        return _initiateStripe(
          amount: finalAmount,
          currency: currency == 'ETB' ? 'usd' : currency.toLowerCase(),
          email: userEmail,
          txRef: txRef,
        );
    }
  }

  // ----------------------------------------------------------
  //  CHAPA Integration
  // ----------------------------------------------------------
  Future<PaymentResult> _initiateChapa({
    required double amount,
    required String currency,
    required String email,
    required String phone,
    required String firstName,
    required String lastName,
    required String txRef,
    String? preferredMethod,
  }) async {
    try {
      final response = await http.post(
        Uri.parse('$chapaBaseUrl/transaction/initialize'),
        headers: {
          'Authorization': 'Bearer $chapaSecretKey',
          'Content-Type': 'application/json',
        },
        body: jsonEncode({
          'amount': amount.toStringAsFixed(2),
          'currency': currency,
          'email': email,
          'first_name': firstName,
          'last_name': lastName,
          'phone_number': phone,
          'tx_ref': txRef,
          'callback_url': 'https://your-backend.com/api/payment/chapa/callback',
          'return_url': 'https://your-app.com/payment/success',
          'customization': {
            'title': 'Fikra Registration',
            'description': 'One-time registration fee',
          },
          if (preferredMethod != null) 'payment_options': preferredMethod,
        }),
      );

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && data['status'] == 'success') {
        final checkoutUrl = data['data']?['checkout_url'] as String?;
        return PaymentResult(
          status: PaymentStatus.pending,
          transactionId: txRef,
          checkoutUrl: checkoutUrl,
          message: 'Checkout URL generated',
          raw: data,
        );
      } else {
        return PaymentResult(
          status: PaymentStatus.failed,
          message: data['message']?.toString() ?? 'Chapa initialization failed',
          raw: data,
        );
      }
    } catch (e) {
      debugPrint('Chapa error: $e');
      return PaymentResult(
        status: PaymentStatus.failed,
        message: e.toString(),
      );
    }
  }

  /// Verify Chapa payment after redirect
  Future<PaymentResult> verifyChapaPayment(String txRef) async {
    try {
      final response = await http.get(
        Uri.parse('$chapaBaseUrl/transaction/verify/$txRef'),
        headers: {
          'Authorization': 'Bearer $chapaSecretKey',
        },
      );

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode == 200 && data['status'] == 'success') {
        final status = data['data']?['status'] as String?;
        if (status == 'success') {
          return PaymentResult(
            status: PaymentStatus.success,
            transactionId: txRef,
            message: 'Payment successful',
            raw: data,
          );
        }
      }

      return PaymentResult(
        status: PaymentStatus.failed,
        transactionId: txRef,
        message: data['message']?.toString() ?? 'Verification failed',
        raw: data,
      );
    } catch (e) {
      return PaymentResult(
        status: PaymentStatus.failed,
        message: e.toString(),
      );
    }
  }

  // ----------------------------------------------------------
  //  STRIPE Integration (client-side + backend intent)
  // ----------------------------------------------------------
  /// In production you must create a PaymentIntent on your backend.
  /// This method calls your backend endpoint.
  Future<PaymentResult> _initiateStripe({
    required double amount,
    required String currency,
    required String email,
    required String txRef,
  }) async {
    try {
      // Call YOUR backend to create a PaymentIntent
      // Never put Stripe secret key in the mobile app!
      final response = await http.post(
        Uri.parse('https://your-backend.com/api/payment/stripe/create-intent'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'amount': (amount * 100).toInt(), // Stripe uses cents
          'currency': currency,
          'email': email,
          'metadata': {
            'tx_ref': txRef,
            'type': 'registration',
          },
        }),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body) as Map<String, dynamic>;
        final clientSecret = data['clientSecret'] as String?;

        return PaymentResult(
          status: PaymentStatus.pending,
          transactionId: txRef,
          message: clientSecret, // pass clientSecret to flutter_stripe
          raw: data,
        );
      }

      return PaymentResult(
        status: PaymentStatus.failed,
        message: 'Failed to create Stripe PaymentIntent',
      );
    } catch (e) {
      debugPrint('Stripe error: $e');
      return PaymentResult(
        status: PaymentStatus.failed,
        message: e.toString(),
      );
    }
  }
}
