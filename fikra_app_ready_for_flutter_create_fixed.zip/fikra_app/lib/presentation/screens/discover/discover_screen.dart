import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../data/repositories/profile_repository.dart';

class DiscoverScreen extends StatefulWidget {
  const DiscoverScreen({super.key});

  @override
  State<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends State<DiscoverScreen>
    with SingleTickerProviderStateMixin {
  final _repo = ProfileRepository();

  late AnimationController _animController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _rotateAnimation;

  List<Map<String, dynamic>> _profiles = [];
  int _currentIndex = 0;
  bool _isLoading = true;
  bool _isAnimating = false;
  String? _error;

  // Fallback demo data when no real profiles yet
  final List<Map<String, dynamic>> _demoProfiles = [
    {
      'id': 'demo1',
      'full_name': 'ሰላም',
      'birth_date': '1998-05-12',
      'bio': 'ቡና እወዳለሁ ☕ • ጉዞ ✈️ • ሙዚቃ 🎵',
      'is_verified': true,
      'user_interests': [
        {'interest': 'ቡና'},
        {'interest': 'ጉዞ'},
        {'interest': 'ሙዚቃ'},
      ],
      'user_photos': [],
      '_demo_gradient': [const Color(0xFFE8B4B8), const Color(0xFFD4A5A5)],
      '_demo_distance': '3 ኪ.ሜ',
    },
    {
      'id': 'demo2',
      'full_name': 'ናትናኤል',
      'birth_date': '1995-08-20',
      'bio': 'ስፖርት 💪 • ቴክኖሎጂ 💻 • ፊልም 🎬',
      'is_verified': true,
      'user_interests': [
        {'interest': 'ስፖርት'},
        {'interest': 'ቴክ'},
        {'interest': 'ፊልም'},
      ],
      'user_photos': [],
      '_demo_gradient': [const Color(0xFFB4C6E8), const Color(0xFF8BA3D0)],
      '_demo_distance': '5 ኪ.ሜ',
    },
    {
      'id': 'demo3',
      'full_name': 'ሂሩት',
      'birth_date': '2000-01-15',
      'bio': 'ስነ-ጥበብ 🎨 • ዳንስ 💃 • ተፈጥሮ 🌿',
      'is_verified': false,
      'user_interests': [
        {'interest': 'ስነ-ጥበብ'},
        {'interest': 'ዳንስ'},
        {'interest': 'ተፈጥሮ'},
      ],
      'user_photos': [],
      '_demo_gradient': [const Color(0xFFE8D4B4), const Color(0xFFD4B896)],
      '_demo_distance': '1 ኪ.ሜ',
    },
  ];

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _slideAnimation = Tween<Offset>(begin: Offset.zero, end: const Offset(1.5, 0))
        .animate(CurvedAnimation(parent: _animController, curve: Curves.easeInOut));
    _rotateAnimation = Tween<double>(begin: 0, end: 0.3).animate(_animController);
    _loadProfiles();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<void> _loadProfiles() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final data = await _repo.getDiscoverProfiles(limit: 30);
      if (mounted) {
        setState(() {
          _profiles = data.isNotEmpty ? data : _demoProfiles;
          _currentIndex = 0;
          _isLoading = false;
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _profiles = _demoProfiles; // fallback
          _isLoading = false;
          _error = null; // keep silent and show demo
        });
      }
    }
  }

  int _calculateAge(String? birthDate) {
    if (birthDate == null) return 25;
    try {
      final birth = DateTime.parse(birthDate);
      final now = DateTime.now();
      int age = now.year - birth.year;
      if (now.month < birth.month || (now.month == birth.month && now.day < birth.day)) {
        age--;
      }
      return age;
    } catch (_) {
      return 25;
    }
  }

  List<String> _extractInterests(Map<String, dynamic> profile) {
    final raw = profile['user_interests'];
    if (raw is List) {
      return raw
          .map((e) => (e is Map ? e['interest'] : e)?.toString() ?? '')
          .where((s) => s.isNotEmpty)
          .toList();
    }
    return [];
  }

  List<Color> _gradientFor(Map<String, dynamic> profile) {
    if (profile['_demo_gradient'] != null) {
      return List<Color>.from(profile['_demo_gradient'] as List);
    }
    // Generate soft gradient from name hash
    final name = (profile['full_name'] ?? 'A').toString();
    final hash = name.codeUnits.fold(0, (a, b) => a + b);
    final colors = [
      [const Color(0xFFE8B4B8), const Color(0xFFD4A5A5)],
      [const Color(0xFFB4C6E8), const Color(0xFF8BA3D0)],
      [const Color(0xFFE8D4B4), const Color(0xFFD4B896)],
      [const Color(0xFFC5E1A5), const Color(0xFFA5D6A7)],
      [const Color(0xFFD1C4E9), const Color(0xFFB39DDB)],
    ];
    return colors[hash % colors.length];
  }

  Future<void> _onAction(bool isLike) async {
    if (_isAnimating || _profiles.isEmpty) return;
    setState(() => _isAnimating = true);

    final profile = _profiles[_currentIndex];
    final userId = profile['id']?.toString();

    // Animate out
    _slideAnimation = Tween<Offset>(
      begin: Offset.zero,
      end: Offset(isLike ? 1.5 : -1.5, 0.2),
    ).animate(CurvedAnimation(parent: _animController, curve: Curves.easeInOut));
    _rotateAnimation = Tween<double>(
      begin: 0,
      end: isLike ? 0.25 : -0.25,
    ).animate(_animController);

    await _animController.forward();
    _animController.reset();

    // Send like to backend (skip demo ids)
    if (isLike && userId != null && !userId.startsWith('demo')) {
      final success = await _repo.likeUser(userId);
      if (success && mounted) {
        // Optional: check if it became a match (could query matches)
      }
    }

    if (_currentIndex < _profiles.length - 1) {
      setState(() {
        _currentIndex++;
        _isAnimating = false;
      });
    } else {
      setState(() => _isAnimating = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('ለዛሬ ይበቃል! ነገ ተመልሰው ይመልከቱ ❤️'),
            backgroundColor: AppColors.primary,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.favorite_rounded, color: AppColors.primary, size: 22),
            const SizedBox(width: 6),
            const Text(
              'Fikra',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: AppColors.primary,
                fontSize: 22,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8),
                ],
              ),
              child: const Icon(Icons.refresh_rounded, size: 20),
            ),
            onPressed: _loadProfiles,
          ),
          const SizedBox(width: 4),
          IconButton(
            icon: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8),
                ],
              ),
              child: const Icon(Icons.tune_rounded, size: 20),
            ),
            onPressed: () {},
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: CircularProgressIndicator(color: AppColors.primary),
      );
    }

    if (_profiles.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.people_outline, size: 64, color: Colors.grey.shade300),
            const SizedBox(height: 16),
            Text(
              'አሁን የሚታዩ ሰዎች የሉም',
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: _loadProfiles,
              child: const Text('እንደገና ሞክር'),
            ),
          ],
        ),
      );
    }

    final profile = _profiles[_currentIndex];
    final name = profile['full_name']?.toString() ?? 'Unknown';
    final age = _calculateAge(profile['birth_date']?.toString());
    final bio = profile['bio']?.toString() ?? '';
    final verified = profile['is_verified'] == true;
    final interests = _extractInterests(profile);
    final distance = profile['_demo_distance']?.toString() ?? '';
    final gradients = _gradientFor(profile);

    return Column(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: SlideTransition(
              position: _slideAnimation,
              child: RotationTransition(
                turns: _rotateAnimation,
                child: _ProfileCard(
                  name: name,
                  age: age,
                  bio: bio,
                  distance: distance,
                  interests: interests,
                  verified: verified,
                  gradientColors: gradients,
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(32, 16, 32, 28),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _RoundButton(
                icon: Icons.close_rounded,
                color: const Color(0xFF8E8E93),
                bgColor: Colors.white,
                size: 60,
                onTap: () => _onAction(false),
              ),
              _RoundButton(
                icon: Icons.favorite_rounded,
                color: Colors.white,
                bgColor: AppColors.primary,
                size: 72,
                onTap: () => _onAction(true),
                elevation: 8,
              ),
              _RoundButton(
                icon: Icons.star_rounded,
                color: AppColors.accent,
                bgColor: Colors.white,
                size: 60,
                onTap: () {},
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _ProfileCard extends StatelessWidget {
  final String name;
  final int age;
  final String bio;
  final String distance;
  final List<String> interests;
  final bool verified;
  final List<Color> gradientColors;

  const _ProfileCard({
    required this.name,
    required this.age,
    required this.bio,
    required this.distance,
    required this.interests,
    required this.verified,
    required this.gradientColors,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.12),
            blurRadius: 24,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: Column(
          children: [
            Expanded(
              flex: 65,
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: gradientColors,
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Stack(
                  children: [
                    Center(
                      child: Icon(
                        Icons.person_rounded,
                        size: 140,
                        color: Colors.white.withOpacity(0.35),
                      ),
                    ),
                    if (distance.isNotEmpty)
                      Positioned(
                        top: 16,
                        left: 16,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.black.withOpacity(0.35),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.location_on_rounded, size: 14, color: Colors.white),
                              const SizedBox(width: 4),
                              Text(
                                distance,
                                style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w500),
                              ),
                            ],
                          ),
                        ),
                      ),
                    if (verified)
                      Positioned(
                        top: 16,
                        right: 16,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.verified_rounded, size: 14, color: Colors.white),
                              SizedBox(width: 4),
                              Text('Verified', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 35,
              child: Container(
                width: double.infinity,
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(22, 18, 22, 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          '$name, $age',
                          style: const TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.bold,
                            letterSpacing: -0.5,
                          ),
                        ),
                        if (verified) ...[
                          const SizedBox(width: 6),
                          const Icon(Icons.verified_rounded, color: AppColors.primary, size: 22),
                        ],
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      bio.isNotEmpty ? bio : 'Bio የለም',
                      style: TextStyle(fontSize: 15, color: Colors.grey.shade600, height: 1.3),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const Spacer(),
                    if (interests.isNotEmpty)
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: interests.map((interest) {
                            return Container(
                              margin: const EdgeInsets.only(right: 8),
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                color: AppColors.primary.withOpacity(0.08),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(color: AppColors.primary.withOpacity(0.15)),
                              ),
                              child: Text(
                                interest,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppColors.primary,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final Color bgColor;
  final double size;
  final VoidCallback onTap;
  final double elevation;

  const _RoundButton({
    required this.icon,
    required this.color,
    required this.bgColor,
    required this.size,
    required this.onTap,
    this.elevation = 4,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: bgColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: bgColor == AppColors.primary
                  ? AppColors.primary.withOpacity(0.4)
                  : Colors.black.withOpacity(0.08),
              blurRadius: elevation * 2,
              offset: Offset(0, elevation / 2),
            ),
          ],
        ),
        child: Icon(icon, color: color, size: size * 0.42),
      ),
    );
  }
}
